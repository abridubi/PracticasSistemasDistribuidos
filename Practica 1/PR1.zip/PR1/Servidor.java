import java.net.*;
import java.io.*;

public class Servidor {
    
     public static void main (String [] args)
    {
        // Se instancia la clase principal para que haga todo lo que tiene que
        // hacer el ejemplo
        new Servidor();
    }
     
     public Servidor(){
        try {
            ServerSocket socket = new ServerSocket (15557);
            
            System.out.println ("Esperando cliente");
            Socket cliente = socket.accept();
            System.out.println ("Conectado con cliente de " + cliente.getInetAddress());
            
            /* setSoLinger() a true hace que el cierre del socket espere a que
               el cliente lea los datos, hasta un máximo de 10 segundos de espera.
             */
            cliente.setSoLinger (true, 10);
            /* Se prepara el flujo de entrada de datos, es decir, la clase encargada
               de leer datos del socket.
            */
            DataInputStream bufferEntrada = new DataInputStream (cliente.getInputStream());
            /* Se crea un dato a leer y se le dice que se rellene con el flujo de 
               entrada de datos.
            */
            Dato aux = new Dato("0");
            aux.readObject (bufferEntrada);
            String suma = String.valueOf(Integer.parseInt(aux.toString()) + 1);
            System.out.println ("Recibido: " + suma);
            
            // El setSoLinger() hará que el cierre espere a que el cliente retire los datos.
            cliente.close();
            
            // Se cierra el socket encargado de aceptar clientes.
            socket.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
