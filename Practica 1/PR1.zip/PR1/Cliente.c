#include <stdio.h>
#include <Socket_Cliente.h>
#include <Socket.h>
#include <stdlib.h>
#include <string.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include <fcntl.h> // for open sockets
#include <unistd.h> // for close sockets


int  main ()
{
	int Socket_Con_Servidor;
	int Longitud_Cadena = 0;
   	int Aux;
	char Cadena[100];

	Socket_Con_Servidor = Abre_Conexion_Inet ("192.168.0.6", "cpp_java");
	if (Socket_Con_Servidor == 1)
	{
		printf ("No puedo establecer conexion con el servidor\n");
		exit (-1);
	}
	
	/*
    * Se va a enviar una cadena de 18 caracteres, incluido el \0. Previamente se
    * envía un entero con el 18.
	*/
	strcpy (Cadena, "Hola Eric desde C");
   	Longitud_Cadena = 18;

   /* Antes de enviar el entero hay que transformalo a formato red */
   	Aux = htonl (Longitud_Cadena);
   	Escribe_Socket (Socket_Con_Servidor, (char *)&Aux, sizeof(Longitud_Cadena));
   	//printf ("Enviado %d\n", Longitud_Cadena-1);

   /* Se envía la cadena */
	Escribe_Socket (Socket_Con_Servidor, Cadena, Longitud_Cadena);
   	printf ("Enviado %s\n", Cadena);

   /* Se lee un entero con la longitud de la cadena, incluido el \0 */
   	Lee_Socket (Socket_Con_Servidor, (char *)&Aux, sizeof(int));
   	Longitud_Cadena = ntohl (Aux);
   	//printf ("Recibido %d\n", Longitud_Cadena-1);

   /* Se lee la cadena de la longitud indicada */
   	Lee_Socket (Socket_Con_Servidor, Cadena, Longitud_Cadena);
   	printf ("Recibido %s\n", Cadena);
   
	close (Socket_Con_Servidor);
}
