import java.io.*;
/**
 * Dato para enviar por el socket. Sus atributos son simples y una Clase Atributo
 */
public class Dato implements Serializable {
   /**
   * Constructor. Guarda la cadena en el atributo d y calcula su longitud para guardarla
   * en el atricuto c.
   */
   public Dato (String numero) {
      // Si la cadena no es null, se guarda la cadena y su longitud 
      if (numero != null)
      {
         //c = cadena.length();
         c = Integer.parseInt(numero);
        //c = numero;
      }
   }

   /* Primer atributo, un int */
   public int c = 0;
     
     
   /* Método para devolver un String en el que se represente el valor de
    * todos los atributos. */
   public String toString () {
       String resultado;
       resultado = Integer.toString(c);
       //resultado = d;
       return resultado;
   }
    
      /*
        Método que lee los atributos de esta clase de un DataInputStream tal cual nos los
        envía un programa en C.
        Este método no contempla el caso de que se envíe una cadena "", es decir, un
        único \0.
      */
     public void readObject(java.io.DataInputStream in) throws IOException {
         /* Se lee la longitud de la cadena y se le resta 1 para eliminar el \0 que
            nos envía C.
         */
         c = in.readInt();
         
         // Array de bytes auxiliar para la lectura de la cadena.
         byte [] aux = null;
         
         aux = new byte[c];    // Se le da el tamaño 
         in.read(aux, 0, c);   // Se leen los bytes
         
     }
}